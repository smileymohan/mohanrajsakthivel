Assessing Car Damage with Convolutional Neural Networks

Assesment of auto claims process with computer vision and deep learning. 
Identification of damage location and severity to accuracies of 79% and 71% respectively.
Trained a pipeline of convolutional neural networks using transfer learning on VGG16 with Keras and Theano to classify damage.  Data scraped from Google Images using Selenium, hand-labeled for classification and supplemented with the Stanford Car Image Dataset.

The code classifies the damage on first gate, second gate, partly damage, completely damage and severify.

Code Requirements -
Sckiit-Learn,Theano,Keras

Inspired from work of - http://neokt.github.io/


